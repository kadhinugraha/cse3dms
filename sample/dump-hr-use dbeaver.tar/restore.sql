--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE gisdb;
--
-- Name: gisdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE gisdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_AU.UTF-8';


ALTER DATABASE gisdb OWNER TO postgres;

\connect gisdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hr; Type: SCHEMA; Schema: -; Owner: kadhinugraha
--

CREATE SCHEMA hr;


ALTER SCHEMA hr OWNER TO kadhinugraha;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: countries; Type: TABLE; Schema: hr; Owner: kadhinugraha
--

CREATE TABLE hr.countries (
    country_id character(2) NOT NULL,
    country_name character varying(40),
    region_id numeric
);


ALTER TABLE hr.countries OWNER TO kadhinugraha;

--
-- Name: departments; Type: TABLE; Schema: hr; Owner: kadhinugraha
--

CREATE TABLE hr.departments (
    department_id numeric(40,0) NOT NULL,
    department_name character varying(30) NOT NULL,
    manager_id numeric(6,0),
    location_id numeric(4,0)
);


ALTER TABLE hr.departments OWNER TO kadhinugraha;

--
-- Name: departments_seq; Type: SEQUENCE; Schema: hr; Owner: kadhinugraha
--

CREATE SEQUENCE hr.departments_seq
    START WITH 280
    INCREMENT BY 10
    NO MINVALUE
    MAXVALUE 9990
    CACHE 1;


ALTER TABLE hr.departments_seq OWNER TO kadhinugraha;

--
-- Name: employees; Type: TABLE; Schema: hr; Owner: kadhinugraha
--

CREATE TABLE hr.employees (
    employee_id numeric(6,0) NOT NULL,
    first_name character varying(20),
    last_name character varying(25) NOT NULL,
    email character varying(25) NOT NULL,
    phone_numeric character varying(20),
    hire_date date NOT NULL,
    job_id character varying(10) NOT NULL,
    salary numeric(8,2),
    commission_pct numeric(2,2),
    manager_id numeric(6,0),
    department_id numeric(4,0),
    CONSTRAINT emp_salary_min CHECK ((salary > (0)::numeric))
);


ALTER TABLE hr.employees OWNER TO kadhinugraha;

--
-- Name: jobs; Type: TABLE; Schema: hr; Owner: kadhinugraha
--

CREATE TABLE hr.jobs (
    job_id character varying(10) NOT NULL,
    job_title character varying(35) NOT NULL,
    min_salary numeric(6,0),
    max_salary numeric(6,0)
);


ALTER TABLE hr.jobs OWNER TO kadhinugraha;

--
-- Name: locations; Type: TABLE; Schema: hr; Owner: kadhinugraha
--

CREATE TABLE hr.locations (
    location_id numeric(4,0) NOT NULL,
    street_address character varying(40),
    postal_code character varying(12),
    city character varying(30) NOT NULL,
    state_province character varying(25),
    country_id character(2)
);


ALTER TABLE hr.locations OWNER TO kadhinugraha;

--
-- Name: regions; Type: TABLE; Schema: hr; Owner: kadhinugraha
--

CREATE TABLE hr.regions (
    region_id numeric NOT NULL,
    region_name character varying(25)
);


ALTER TABLE hr.regions OWNER TO kadhinugraha;

--
-- Name: emp_details_view; Type: VIEW; Schema: hr; Owner: kadhinugraha
--

CREATE VIEW hr.emp_details_view AS
 SELECT e.employee_id,
    e.job_id,
    e.manager_id,
    e.department_id,
    d.location_id,
    l.country_id,
    e.first_name,
    e.last_name,
    e.salary,
    e.commission_pct,
    d.department_name,
    j.job_title,
    l.city,
    l.state_province,
    c.country_name,
    r.region_name
   FROM hr.employees e,
    hr.departments d,
    hr.jobs j,
    hr.locations l,
    hr.countries c,
    hr.regions r
  WHERE ((e.department_id = d.department_id) AND (d.location_id = l.location_id) AND (l.country_id = c.country_id) AND (c.region_id = r.region_id) AND ((j.job_id)::text = (e.job_id)::text));


ALTER TABLE hr.emp_details_view OWNER TO kadhinugraha;

--
-- Name: employees_seq; Type: SEQUENCE; Schema: hr; Owner: kadhinugraha
--

CREATE SEQUENCE hr.employees_seq
    START WITH 207
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hr.employees_seq OWNER TO kadhinugraha;

--
-- Name: job_history; Type: TABLE; Schema: hr; Owner: kadhinugraha
--

CREATE TABLE hr.job_history (
    employee_id numeric(6,0) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    job_id character varying(10) NOT NULL,
    department_id numeric(4,0),
    CONSTRAINT jhist_date_interval CHECK ((end_date > start_date))
);


ALTER TABLE hr.job_history OWNER TO kadhinugraha;

--
-- Name: locations_seq; Type: SEQUENCE; Schema: hr; Owner: kadhinugraha
--

CREATE SEQUENCE hr.locations_seq
    START WITH 3300
    INCREMENT BY 100
    NO MINVALUE
    MAXVALUE 9900
    CACHE 1;


ALTER TABLE hr.locations_seq OWNER TO kadhinugraha;

--
-- Data for Name: countries; Type: TABLE DATA; Schema: hr; Owner: kadhinugraha
--

COPY hr.countries (country_id, country_name, region_id) FROM stdin;
\.
COPY hr.countries (country_id, country_name, region_id) FROM '$$PATH$$/5370.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: hr; Owner: kadhinugraha
--

COPY hr.departments (department_id, department_name, manager_id, location_id) FROM stdin;
\.
COPY hr.departments (department_id, department_name, manager_id, location_id) FROM '$$PATH$$/5373.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: hr; Owner: kadhinugraha
--

COPY hr.employees (employee_id, first_name, last_name, email, phone_numeric, hire_date, job_id, salary, commission_pct, manager_id, department_id) FROM stdin;
\.
COPY hr.employees (employee_id, first_name, last_name, email, phone_numeric, hire_date, job_id, salary, commission_pct, manager_id, department_id) FROM '$$PATH$$/5376.dat';

--
-- Data for Name: job_history; Type: TABLE DATA; Schema: hr; Owner: kadhinugraha
--

COPY hr.job_history (employee_id, start_date, end_date, job_id, department_id) FROM stdin;
\.
COPY hr.job_history (employee_id, start_date, end_date, job_id, department_id) FROM '$$PATH$$/5378.dat';

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: hr; Owner: kadhinugraha
--

COPY hr.jobs (job_id, job_title, min_salary, max_salary) FROM stdin;
\.
COPY hr.jobs (job_id, job_title, min_salary, max_salary) FROM '$$PATH$$/5375.dat';

--
-- Data for Name: locations; Type: TABLE DATA; Schema: hr; Owner: kadhinugraha
--

COPY hr.locations (location_id, street_address, postal_code, city, state_province, country_id) FROM stdin;
\.
COPY hr.locations (location_id, street_address, postal_code, city, state_province, country_id) FROM '$$PATH$$/5371.dat';

--
-- Data for Name: regions; Type: TABLE DATA; Schema: hr; Owner: kadhinugraha
--

COPY hr.regions (region_id, region_name) FROM stdin;
\.
COPY hr.regions (region_id, region_name) FROM '$$PATH$$/5369.dat';

--
-- Name: departments_seq; Type: SEQUENCE SET; Schema: hr; Owner: kadhinugraha
--

SELECT pg_catalog.setval('hr.departments_seq', 280, false);


--
-- Name: employees_seq; Type: SEQUENCE SET; Schema: hr; Owner: kadhinugraha
--

SELECT pg_catalog.setval('hr.employees_seq', 207, false);


--
-- Name: locations_seq; Type: SEQUENCE SET; Schema: hr; Owner: kadhinugraha
--

SELECT pg_catalog.setval('hr.locations_seq', 3300, false);


--
-- Name: countries country_c_id_pk; Type: CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.countries
    ADD CONSTRAINT country_c_id_pk PRIMARY KEY (country_id);


--
-- Name: departments dept_id_pk; Type: CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.departments
    ADD CONSTRAINT dept_id_pk PRIMARY KEY (department_id);


--
-- Name: employees emp_email_uk; Type: CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.employees
    ADD CONSTRAINT emp_email_uk UNIQUE (email);


--
-- Name: employees emp_emp_id_pk; Type: CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.employees
    ADD CONSTRAINT emp_emp_id_pk PRIMARY KEY (employee_id);


--
-- Name: job_history jhist_emp_id_st_date_pk; Type: CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.job_history
    ADD CONSTRAINT jhist_emp_id_st_date_pk PRIMARY KEY (employee_id, start_date);


--
-- Name: jobs job_id_pk; Type: CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.jobs
    ADD CONSTRAINT job_id_pk PRIMARY KEY (job_id);


--
-- Name: locations loc_id_pk; Type: CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.locations
    ADD CONSTRAINT loc_id_pk PRIMARY KEY (location_id);


--
-- Name: regions reg_id_pk; Type: CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.regions
    ADD CONSTRAINT reg_id_pk PRIMARY KEY (region_id);


--
-- Name: countries countr_reg_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.countries
    ADD CONSTRAINT countr_reg_fk FOREIGN KEY (region_id) REFERENCES hr.regions(region_id);


--
-- Name: departments dept_loc_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.departments
    ADD CONSTRAINT dept_loc_fk FOREIGN KEY (location_id) REFERENCES hr.locations(location_id);


--
-- Name: departments dept_mgr_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.departments
    ADD CONSTRAINT dept_mgr_fk FOREIGN KEY (manager_id) REFERENCES hr.employees(employee_id) DEFERRABLE;


--
-- Name: employees emp_dept_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.employees
    ADD CONSTRAINT emp_dept_fk FOREIGN KEY (department_id) REFERENCES hr.departments(department_id);


--
-- Name: employees emp_job_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.employees
    ADD CONSTRAINT emp_job_fk FOREIGN KEY (job_id) REFERENCES hr.jobs(job_id);


--
-- Name: employees emp_manager_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.employees
    ADD CONSTRAINT emp_manager_fk FOREIGN KEY (manager_id) REFERENCES hr.employees(employee_id);


--
-- Name: job_history jhist_dept_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.job_history
    ADD CONSTRAINT jhist_dept_fk FOREIGN KEY (department_id) REFERENCES hr.departments(department_id);


--
-- Name: job_history jhist_emp_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.job_history
    ADD CONSTRAINT jhist_emp_fk FOREIGN KEY (employee_id) REFERENCES hr.employees(employee_id);


--
-- Name: job_history jhist_job_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.job_history
    ADD CONSTRAINT jhist_job_fk FOREIGN KEY (job_id) REFERENCES hr.jobs(job_id);


--
-- Name: locations loc_c_id_fk; Type: FK CONSTRAINT; Schema: hr; Owner: kadhinugraha
--

ALTER TABLE ONLY hr.locations
    ADD CONSTRAINT loc_c_id_fk FOREIGN KEY (country_id) REFERENCES hr.countries(country_id);


--
-- PostgreSQL database dump complete
--

